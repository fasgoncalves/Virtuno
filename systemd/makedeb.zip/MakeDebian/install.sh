#!/bin/bash
echo "Installing Virtuno as systemd service..."

cp virtuno.service /etc/systemd/system/virtuno.service
systemctl daemon-reload
systemctl enable virtuno
echo "Installation complete. You can now run: sudo systemctl start virtuno"